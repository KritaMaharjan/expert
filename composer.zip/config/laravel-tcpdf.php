<?php

return [
	'page_format' => 'A4',
	'page_orientation' => 'P',
	'page_units' => 'mm',
	'unicode' => true,
	'encoding' => 'UTF-8',
	'font_directory' => '',
	'image_directory' => '',
	'tcpdf_throw_exception' => false,
];