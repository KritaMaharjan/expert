<?php namespace App\Http\Controllers\System;

use Illuminate\Http\Request;
use App\Models\System\Lead\Lead;

class DashboardController extends BaseController {

    protected $request;
    protected $lead;

    public function __construct(Lead $lead, Request $request)
    {
        parent::__construct();
        $this->request = $request;
        $this->lead = $lead;
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        return view('system.dashboard.index');
    }

    public function dataJson()
    {
        if ($this->request->ajax()) {
            $select = ['id', 'status', 'ex_clients_id', 'created_at'];
            $json = $this->lead->dataTablePagination($this->request, $select, true);
            echo json_encode($json, JSON_PRETTY_PRINT);
        } else {
            show_404();
        }
    }

}
