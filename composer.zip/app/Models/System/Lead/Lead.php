<?php
namespace App\Models\System\Lead;

use App\Models\System\Client\Client;
use App\Models\System\Loan\Loan;
use App\Models\System\Log\LeadLog;
use App\Models\System\Log\Log;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Lead extends Model
{

    protected $table = 'ex_leads';
    protected $fillable = ['referral_notes', 'feedback', 'status', 'property_search_area', 'ex_clients_id', 'added_by_users_id'];

    public function loan()
    {
        return $this->hasOne('App\Models\System\Loan\loan', 'ex_leads_id');
    }

    //Lead can have many logs
    public function leadlogs()
    {
        return $this->hasMany('App\Models\System\Log\LeadLog', 'ex_lead_id');
    }

    function add(array $request)
    {
        DB::beginTransaction();

        try {
            $lead = Lead::create([
                'referral_notes' => $request['referral_notes'],
                'feedback' => $request['feedback'],
                'status' => 0, //0 unassigned 1 assigned
                'property_search_area' => $request['property_search_area'],
                'ex_clients_id' => $request['ex_clients_id'],
                'added_by_users_id' => \Auth::user()->id
            ]);

            $loan = Loan::create([
                'loan_purpose' => $request['loan_purpose'],
                'amount' => $request['amount'],
                'area' => $request['area'],
                'loan_type' => $request['loan_type'],
                'ex_leads_id' => $lead->id,
                'interest_rate' => $request['interest_rate'],
                'bank_name' => $request['bank_name'],
                'interest_type' => $request['interest_type'],
                'interest_date_till' => $request['interest_date_till']
            ]);

            //add logs
            $log = Log::create([
                'added_by' => \Auth::user()->id,
                'comment' => 'Lead Created'
            ]);

            LeadLog::create([
                'ex_lead_id' => $lead->id,
                'log_id' => $log->id
            ]);

            DB::commit();
            return $lead->id;
        } catch (\Exception $e) {
            DB::rollback();
            dd($e);
            return false;
        }
    }

    /* Assign lead to sales person */
    function assign(array $request, $lead_id)
    {
        DB::beginTransaction();

        try {
            $lead = Lead::find($lead_id);

            ClientLeadAssign::create([
                'ex_leads_id' => $lead_id,
                'meeting_datetime' => $request['meeting_datetime'],
                'meeting_place' => $request['meeting_place'],
                'description' => $request['description'],
                'assign_to' => $request['assign_to']
            ]);

            $lead->status = 1;
            $lead->save();

            DB::commit();
            return true;

        } catch (\Exception $e) {
            DB::rollback();
            dd($e);
            return false;
        }
    }

    function edit(array $request, $lead_id)
    {
        DB::beginTransaction();

        try {
            $lead = Lead::find($lead_id);

            $lead->referral_notes = $request['referral_notes'];
            $lead->feedback = $request['feedback'];
            $lead->property_search_area = $request['property_search_area'];
            $lead->ex_clients_id = $request['ex_clients_id'];

            $lead->save();

            $loan = Loan::where('ex_leads_id', $lead->id)->first();
            $loan->loan_purpose = $request['loan_purpose'];
            $loan->amount = $request['amount'];
            $loan->area = $request['area'];
            $loan->loan_type = $request['loan_type'];
            $loan->interest_rate = $request['interest_rate'];
            $loan->bank_name = $request['bank_name'];
            $loan->interest_type = $request['interest_type'];
            $loan->interest_date_till = $request['interest_date_till'];
            /*foreach($request['loan'] as $key => $loan_element) {
                $loan->$key = $loan_element;
            }*/
            $loan->save();
            DB::commit();
            return true;

        } catch (\Exception $e) {
            DB::rollback();
            dd($e);
            return false;
        }
    }
    
    /*
     * Delete lead
     * parameter lead id int
    */
    function remove($lead_id)
    {
        DB::beginTransaction();

        try {
            //get details
            $lead = Lead::find($lead_id);

            //loan details
            $loan_details = Loan::where('ex_leads_id', $lead_id)->first();

            //lead assign
            $lead_assign = ClientLeadAssign::where('ex_leads_id', $lead_id);
            $lead_assign->delete();
            $loan_details->delete();

            //logs
            $lead_logs = LeadLog::where('ex_lead_id', $lead_id)->get();
            $lead_logs->delete();

            foreach($lead_logs as $lead_log) {
                $log = Log::find($lead_log->log_id);
                $log->delete();
            }

            $lead->delete();
            DB::commit();
            // all good
        } catch (\Exception $e) {
            DB::rollback();
            dd($e);
            // something went wrong
        }
    }
    

    /* *
     *  Display data for ajax pagination
     *  Output stdClass
     * */
    function dataTablePagination(Request $request, array $select = array(), $unassigned_only = false)
    {
        if ((is_array($select) AND count($select) < 1)) {
            $select = "*";
        }
        $take = ($request->input('length') > 0) ? $request->input('length') : 10;
        $start = ($request->input('start') > 0) ? $request->input('start') : 0;

        $search = $request->input('search');
        $search = $search['value'];
        $order = $request->input('order');
        $column_id = $order[0]['column'];
        $columns = $request->input('columns');
        $orderColumn = $columns[$column_id]['data'];
        $orderdir = $order[0]['dir'];

        $lead = array();

        $query = $this->select($select)->with('loan')->first();

        if ($orderColumn != '' AND $orderdir != '') {
            $query = $query->orderBy($orderColumn, $orderdir);
        }

        /*if ($search != '') {
            $query = $query->where('domain', 'LIKE', "%$search%")->orwhere('email', 'LIKE', "%$search%");
        }*/
        $lead['total'] = $query->count();

        $query->skip($start)->take($take);

        if($unassigned_only == true)
        $query = $query->where('status', 0);

        $data = $query->get();

        foreach ($data as $key => &$value) {
            $client = Client::find($value->ex_clients_id);
            $value->client = $client->given_name . " " . $client->surname;
            $value->email = $client->email;
            $value->actual_status = $value->status;
            $value->amount = $value->loan->amount;
            $value->status = ($value->status == 0)?'<span class="label label-danger">Unassigned</span>':'<span class="label label-success">Assigned</span>';
        }
        $lead['data'] = $data->toArray();
        $json = new \stdClass();
        $json->draw = ($request->input('draw') > 0) ? $request->input('draw') : 1;
        $json->recordsTotal = $lead['total'];
        $json->recordsFiltered = $lead['total'];
        $json->data = $lead['data'];

        return $json;
    }

    function toData()
    {
        $this->show_url = '';// tenant()->url('client/' . $this->id);
        $this->edit_url = '';//tenant()->url('client/' . $this->id . '/edit');
        return $this->toArray();
    }

    /* Add log details to a lead */
    function addLog(array $request, $lead_id)
    {
        DB::beginTransaction();
        try {

            $log = Log::create([
                'added_by' => \Auth::user()->id,
                'comment' => $request['comment'],
                'emailed_to' => $request['emailed_to'],
                'email' => ($request['emailed_to'] == '')? 0 : 1,
            ]);

            LeadLog::create([
                'ex_lead_id' => $lead_id,
                'log_id' => $log->id
            ]);

            DB::commit();
            return true;

        } catch (\Exception $e) {
            DB::rollback();
            dd($e);
            return false;
        }
    }
} 